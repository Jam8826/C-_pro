﻿namespace EMS___SCNE
{


    public partial class _EMS_SCNEDataSet
    {
    }
}
namespace EMS___SCNE {
    
    
    public partial class _EMS_SCNEDataSet {
    }
}
