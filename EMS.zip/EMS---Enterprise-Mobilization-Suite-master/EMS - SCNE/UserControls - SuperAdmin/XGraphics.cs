﻿using iTextSharp.text.pdf;
using System;

namespace EMS___SCNE.UserControls___SuperAdmin
{
    internal class XGraphics
    {
        internal static XGraphics FromPdfPage(PdfPage page)
        {
            throw new NotImplementedException();
        }
    }
}