﻿namespace EMS___SCNE.UserControls___SuperAdmin
{
    internal class XFont
    {
    }
}