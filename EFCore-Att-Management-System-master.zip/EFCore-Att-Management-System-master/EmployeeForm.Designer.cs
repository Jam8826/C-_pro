﻿namespace EFCoreAttMgtSystem
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            identityTextBox = new TextBox();
            fullnameTextBox = new TextBox();
            positionTextBox = new TextBox();
            cardnoTextBox = new TextBox();
            usernametextBox = new TextBox();
            passwordtextBox = new TextBox();
            addnewButton = new Button();
            saveButton = new Button();
            updateButton = new Button();
            panel1 = new Panel();
            panel2 = new Panel();
            dataGridView1 = new DataGridView();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(799, 0);
            label1.Name = "label1";
            label1.Size = new Size(942, 159);
            label1.TabIndex = 0;
            label1.Text = "Employee Form";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(68, 251);
            label2.Name = "label2";
            label2.Size = new Size(394, 72);
            label2.TabIndex = 1;
            label2.Text = "Employee Info";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14.1F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(116, 341);
            label3.Name = "label3";
            label3.Size = new Size(245, 62);
            label3.TabIndex = 1;
            label3.Text = "Identity ID";
            label3.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.1F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(116, 422);
            label4.Name = "label4";
            label4.Size = new Size(236, 62);
            label4.TabIndex = 1;
            label4.Text = "Full Name";
            label4.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 14.1F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(116, 503);
            label5.Name = "label5";
            label5.Size = new Size(192, 62);
            label5.TabIndex = 1;
            label5.Text = "Position";
            label5.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 14.1F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(116, 583);
            label6.Name = "label6";
            label6.Size = new Size(200, 62);
            label6.TabIndex = 1;
            label6.Text = "Card No";
            label6.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 14.1F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(116, 771);
            label7.Name = "label7";
            label7.Size = new Size(236, 62);
            label7.TabIndex = 1;
            label7.Text = "Username";
            label7.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 14.1F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(116, 852);
            label8.Name = "label8";
            label8.Size = new Size(221, 62);
            label8.TabIndex = 1;
            label8.Text = "Password";
            label8.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(68, 689);
            label9.Name = "label9";
            label9.Size = new Size(394, 72);
            label9.TabIndex = 1;
            label9.Text = "Employee Info";
            // 
            // identityTextBox
            // 
            identityTextBox.BorderStyle = BorderStyle.FixedSingle;
            identityTextBox.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Regular, GraphicsUnit.Point);
            identityTextBox.Location = new Point(367, 341);
            identityTextBox.Name = "identityTextBox";
            identityTextBox.ReadOnly = true;
            identityTextBox.Size = new Size(656, 78);
            identityTextBox.TabIndex = 2;
            // 
            // fullnameTextBox
            // 
            fullnameTextBox.BorderStyle = BorderStyle.FixedSingle;
            fullnameTextBox.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Regular, GraphicsUnit.Point);
            fullnameTextBox.Location = new Point(367, 425);
            fullnameTextBox.Name = "fullnameTextBox";
            fullnameTextBox.Size = new Size(656, 78);
            fullnameTextBox.TabIndex = 2;
            // 
            // positionTextBox
            // 
            positionTextBox.BorderStyle = BorderStyle.FixedSingle;
            positionTextBox.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Regular, GraphicsUnit.Point);
            positionTextBox.Location = new Point(367, 509);
            positionTextBox.Name = "positionTextBox";
            positionTextBox.Size = new Size(656, 78);
            positionTextBox.TabIndex = 2;
            // 
            // cardnoTextBox
            // 
            cardnoTextBox.BorderStyle = BorderStyle.FixedSingle;
            cardnoTextBox.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Regular, GraphicsUnit.Point);
            cardnoTextBox.Location = new Point(367, 593);
            cardnoTextBox.Name = "cardnoTextBox";
            cardnoTextBox.Size = new Size(656, 78);
            cardnoTextBox.TabIndex = 2;
            // 
            // usernametextBox
            // 
            usernametextBox.BorderStyle = BorderStyle.FixedSingle;
            usernametextBox.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Regular, GraphicsUnit.Point);
            usernametextBox.Location = new Point(367, 771);
            usernametextBox.Name = "usernametextBox";
            usernametextBox.Size = new Size(656, 78);
            usernametextBox.TabIndex = 2;
            // 
            // passwordtextBox
            // 
            passwordtextBox.BorderStyle = BorderStyle.FixedSingle;
            passwordtextBox.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Regular, GraphicsUnit.Point);
            passwordtextBox.Location = new Point(367, 855);
            passwordtextBox.Name = "passwordtextBox";
            passwordtextBox.Size = new Size(656, 78);
            passwordtextBox.TabIndex = 2;
            // 
            // addnewButton
            // 
            addnewButton.BackColor = Color.FromArgb(128, 255, 255);
            addnewButton.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Bold, GraphicsUnit.Point);
            addnewButton.Location = new Point(74, 1007);
            addnewButton.Name = "addnewButton";
            addnewButton.Size = new Size(323, 96);
            addnewButton.TabIndex = 3;
            addnewButton.Text = "Add New";
            addnewButton.UseVisualStyleBackColor = false;
            addnewButton.Click += addnewButton_Click;
            // 
            // saveButton
            // 
            saveButton.BackColor = Color.Blue;
            saveButton.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Bold, GraphicsUnit.Point);
            saveButton.ForeColor = Color.White;
            saveButton.Location = new Point(416, 1007);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(323, 96);
            saveButton.TabIndex = 3;
            saveButton.Text = "Save";
            saveButton.UseVisualStyleBackColor = false;
            saveButton.Click += saveButton_Click;
            // 
            // updateButton
            // 
            updateButton.BackColor = Color.Lime;
            updateButton.Font = new Font("Segoe UI", 15.9000006F, FontStyle.Bold, GraphicsUnit.Point);
            updateButton.Location = new Point(754, 1007);
            updateButton.Name = "updateButton";
            updateButton.Size = new Size(323, 96);
            updateButton.TabIndex = 3;
            updateButton.Text = "Update";
            updateButton.UseVisualStyleBackColor = false;
            updateButton.Click += updateButton_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Blue;
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 1181);
            panel1.Name = "panel1";
            panel1.Size = new Size(2527, 87);
            panel1.TabIndex = 4;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Blue;
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(2527, 193);
            panel2.TabIndex = 5;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = Color.Black;
            dataGridView1.Location = new Point(1098, 341);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 102;
            dataGridView1.RowTemplate.Height = 49;
            dataGridView1.Size = new Size(1375, 762);
            dataGridView1.TabIndex = 6;
            dataGridView1.CellContentClick += DataGridView1_SelectionChanged;
            // 
            // EmployeeForm
            // 
            AutoScaleDimensions = new SizeF(240F, 240F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Color.FromArgb(255, 192, 255);
            ClientSize = new Size(2527, 1268);
            Controls.Add(dataGridView1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(updateButton);
            Controls.Add(saveButton);
            Controls.Add(addnewButton);
            Controls.Add(passwordtextBox);
            Controls.Add(cardnoTextBox);
            Controls.Add(usernametextBox);
            Controls.Add(positionTextBox);
            Controls.Add(fullnameTextBox);
            Controls.Add(identityTextBox);
            Controls.Add(label8);
            Controls.Add(label5);
            Controls.Add(label7);
            Controls.Add(label4);
            Controls.Add(label6);
            Controls.Add(label3);
            Controls.Add(label9);
            Controls.Add(label2);
            Font = new Font("Segoe UI", 14.1F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(5);
            Name = "EmployeeForm";
            Text = "EmployeeForm";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox identityTextBox;
        private TextBox fullnameTextBox;
        private TextBox positionTextBox;
        private TextBox cardnoTextBox;
        private TextBox usernametextBox;
        private TextBox passwordtextBox;
        private Button addnewButton;
        private Button saveButton;
        private Button updateButton;
        private Panel panel1;
        private Panel panel2;
        private DataGridView dataGridView1;
    }
}