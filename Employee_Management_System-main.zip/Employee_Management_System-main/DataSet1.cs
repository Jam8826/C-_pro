﻿namespace EMS
{


    partial class DataSet1
    {
    }
}

namespace EMS.DataSet1TableAdapters {
    
    
    public partial class AdminTableAdapter {
    }
}
