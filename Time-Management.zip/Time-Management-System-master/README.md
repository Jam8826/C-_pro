# Time-Management-System
Time tracking and attendance monitoring program for employers to track the check-in &amp; check-out time of an employee along with the hour-wise detail tracker.

# Prerequisites
You'll need the following softwares installed - 
  1. .NET Framework 4.5.2
  2. Visual Studio 2019
  3. Registered account on https://remotemysql.com/
  4. T-SQL scripts used in this project are present in SQL folder.  
  5. MySQL Data Connector: https://dev.mysql.com/downloads/connector/net/
