# NTCS Attendance Kiosk
 The kiosk program for the AtteNTCS attendance management system.

See the [wiki](https://github.com/NorthTorontoChristianSchool/NTCS-Attendance-Kiosk/wiki) for documentation.
