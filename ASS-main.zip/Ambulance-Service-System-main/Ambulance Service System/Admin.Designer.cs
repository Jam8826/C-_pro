﻿
namespace Ambulance_Service_System
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.manage_Employee = new System.Windows.Forms.Button();
            this.performance = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Parking = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.AreaData = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(348, 1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(489, 229);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(527, 258);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Admin";
            // 
            // manage_Employee
            // 
            this.manage_Employee.Location = new System.Drawing.Point(136, 512);
            this.manage_Employee.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.manage_Employee.Name = "manage_Employee";
            this.manage_Employee.Size = new System.Drawing.Size(96, 30);
            this.manage_Employee.TabIndex = 2;
            this.manage_Employee.Text = "Logout";
            this.manage_Employee.UseVisualStyleBackColor = true;
            this.manage_Employee.Click += new System.EventHandler(this.manage_Employee_Click);
            // 
            // performance
            // 
            this.performance.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.performance.Location = new System.Drawing.Point(659, 345);
            this.performance.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.performance.Name = "performance";
            this.performance.Size = new System.Drawing.Size(151, 54);
            this.performance.TabIndex = 2;
            this.performance.Text = "Performance Report";
            this.performance.UseVisualStyleBackColor = false;
            this.performance.Click += new System.EventHandler(this.performance_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button1.Location = new System.Drawing.Point(335, 345);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(151, 54);
            this.button1.TabIndex = 2;
            this.button1.Text = "Manage Employee";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Parking
            // 
            this.Parking.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.Parking.Location = new System.Drawing.Point(659, 457);
            this.Parking.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Parking.Name = "Parking";
            this.Parking.Size = new System.Drawing.Size(151, 54);
            this.Parking.TabIndex = 2;
            this.Parking.Text = "Parking Management";
            this.Parking.UseVisualStyleBackColor = false;
            this.Parking.Click += new System.EventHandler(this.Parking_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.manage_Employee);
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(267, 601);
            this.panel1.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkRed;
            this.label4.Location = new System.Drawing.Point(32, 158);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Ambulance Service System";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(267, 208);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // AreaData
            // 
            this.AreaData.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.AreaData.Location = new System.Drawing.Point(335, 457);
            this.AreaData.Margin = new System.Windows.Forms.Padding(4);
            this.AreaData.Name = "AreaData";
            this.AreaData.Size = new System.Drawing.Size(151, 54);
            this.AreaData.TabIndex = 8;
            this.AreaData.Text = "Area Data";
            this.AreaData.UseVisualStyleBackColor = false;
            this.AreaData.Click += new System.EventHandler(this.AreaData_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(993, 622);
            this.Controls.Add(this.AreaData);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.performance);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Parking);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Admin";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button manage_Employee;
        private System.Windows.Forms.Button performance;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Parking;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button AreaData;
    }
}